import os
import time
import sys
from scipy.spatial.transform import Rotation
import numpy as np
import rclpy
from rclpy.node import Node
import DR_init

from od_msg.srv import SrvDepthPosition
from od_msg.srv import SrvInplaneAngle
from std_srvs.srv import Trigger
from ament_index_python.packages import get_package_share_directory
from robot_control.onrobot import RG
from od_msg.srv import TTS

package_path = get_package_share_directory("pick_and_place_voice")

# for single robot
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

JREADY = [-0.08, 25.45, 32.04, 0, 122.54, 0]
BUCKET_POS = [0, 0, 90, 67, 90, 0]
CHARGER_POS = [424.21, 227.82, 65.65, 11.92, 179.91, 12.27]
CHARGER_POS_FINAL = [268.11, -29.81, 70.08, 169.8, 179.8, -144.85]
CHARGER_PAD = [424.180, 84.130, 5.810, 137.34, 179.77, 138.34]

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
DEPTH_OFFSET = -5.0
MIN_DEPTH = 2.0


DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

rclpy.init()
dsr_node = rclpy.create_node("robot_control_node", namespace=ROBOT_ID)
DR_init.__dsr__node = dsr_node

try:
    from DSR_ROBOT2 import movej, movel, get_current_posx, mwait, get_current_posj, release_compliance_ctrl, check_force_condition, task_compliance_ctrl, set_desired_force, release_force, DR_FC_MOD_REL, DR_AXIS_Z
except ImportError as e:
    print(f"Error importing DSR_ROBOT2: {e}")
    sys.exit()

########### Gripper Setup. Do not modify this area ############

gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)


########### Robot Controller ############
goals = [
    [274.180, -224.130, 5.810, 137.34, 179.77, 138.34],
    [424.180, -224.130, 5.810, 137.34, 179.77, 138.34],
    [574.180, -224.130, 5.810, 137.34, 179.77, 138.34]
]

ITEM_KO = {
    "phone": "휴대폰",
    "book": "책",
    "wallet": "지갑",
    "laptop": "노트북",
    "hand": "손",
    "lotion": "로션",
    "vitamin": "비타민",
    "airpods": "에어팟",
    "pencilcase": "필통"
}

# ----- Hand delivery params -----
J1_SWEEP_DEG = 90            # 1번 조인트로 두리번 각도 (±90)
J1_STEP_DEG  = 15             # 스텝
HAND_MAX_DIST_MM   = 300.0    # 손 후보 최대 거리(30cm)
LIFT_AFTER_GRAB_MM = 200.0    # 폰 집은 후 들어올리는 높이
APPROACH_OVERHAND_MM = 120.0  # 손 위로 접근 오프셋
DROP_OFFSET_MM       = -80.0  # 내려가서 전달할 깊이

class RobotController(Node):
    def __init__(self):
        super().__init__("pick_and_place")
        self.init_robot()

        self.get_position_client = self.create_client(
            SrvDepthPosition, "/get_3d_position"
        )
        while not self.get_position_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_depth_position service...")
        self.get_position_request = SrvDepthPosition.Request()

        self.get_keyword_client = self.create_client(Trigger, "/get_keyword")
        while not self.get_keyword_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_keyword service...")
        self.get_keyword_request = Trigger.Request()

        self.skeleton_client = self.create_client(Trigger, "/skeleton_service")
        while not self.skeleton_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for skeleton_service service...")
        
        self.stretching_task = self.create_client(Trigger, "/stretching_task")
        while not self.stretching_task.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for stretching service...")

        # ✅ TTS 서비스 클라이언트 (요청은 매번 새 Request 생성)
        self.tts_client = self.create_client(TTS, "tts/speak")
        while not self.tts_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for tts/speak service...")
        
        self.angle_client = self.create_client(SrvInplaneAngle, "/get_inplane_angle")
        while not self.angle_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_inplane_angle service...")
        
         # ✅ outlet/get_base_xyz (Trigger) 서비스 클라이언트 추가
        self.outlet_client = self.create_client(Trigger, "/get_base_xyz")
        while not self.outlet_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for outlet/get_base_xyz service...")

    # ----------------- tts 호출 -----------------
    def speak(self, text: str, stream: bool = True, timeout_sec: float = 10.0) -> bool:
        text = (text or "").strip()
        if not text:
            self.get_logger().warn("speak(): 빈 텍스트라 요청하지 않습니다.")
            return False

        # 서비스 준비 체크(필요 시 재확인)
        if not self.tts_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error("speak(): tts/speak 서비스가 준비되지 않았습니다.")
            return False

        req = TTS.Request()
        req.text = text
        req.stream = stream

        future = self.tts_client.call_async(req)

        # 타임아웃을 지원하는 안전 대기
        start = time.time()
        while rclpy.ok() and not future.done():
            rclpy.spin_once(self, timeout_sec=0.1)
            if (time.time() - start) > timeout_sec:
                self.get_logger().error("speak(): TTS 서비스 응답 타임아웃")
                return False

        if future.cancelled():
            self.get_logger().error("speak(): future가 취소되었습니다.")
            return False

        if future.exception() is not None:
            self.get_logger().error(f"speak(): 서비스 예외 - {future.exception()}")
            return False

        res = future.result()
        if not res:
            self.get_logger().error("speak(): 응답이 None 입니다.")
            return False

        if res.ok:
            self.get_logger().info(f"speak(): OK - {res.detail}")
            return True
        else:
            self.get_logger().warn(f"speak(): 실패 - {res.detail}")
            return False

    # ----------------- 각도 정렬 요청 -----------------
    def get_inplane_angle(self, target: str, timeout_sec: float = 5.0):
        req = SrvInplaneAngle.Request(); req.target = target
        fut = self.angle_client.call_async(req)
        start = time.time()
        while rclpy.ok() and not fut.done():
            rclpy.spin_once(self, timeout_sec=0.05)
            if (time.time() - start) > timeout_sec:
                return None
        res = fut.result()
        return float(res.angle_deg) if (res and res.ok) else None
    
    # ----------------- 좌표 변환 -----------------
    def get_robot_pose_matrix(self, x, y, z, rx, ry, rz):
        R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
        T = np.eye(4); T[:3, :3] = R; T[:3, 3] = [x, y, z]
        return T

    def transform_to_base(self, camera_coords, gripper2cam_path, robot_pos):
        gripper2cam = np.load(gripper2cam_path)
        coord = np.append(np.array(camera_coords), 1)
        x, y, z, rx, ry, rz = robot_pos
        base2gripper = self.get_robot_pose_matrix(x, y, z, rx, ry, rz)
        base2cam = base2gripper @ gripper2cam
        td_coord = np.dot(base2cam, coord)
        return td_coord[:3]

    # ----------------- 사용자 인식 위치로 이동 -----------------
    def move_to_bucket(self):
        self.get_logger().info(f"Moving to BUCKET_POS: {BUCKET_POS}")
        movej(BUCKET_POS, vel=VELOCITY, acc=ACC)
        mwait()

    # ----------------- 기본 위치로 이동 -----------------
    def init_robot(self):
        movej(JREADY, vel=VELOCITY, acc=ACC)
        mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)
        
    # ----------------- 디텍팅 오브젝트 이름 tts 한국어 변환 용 -----------------
    def get_item_korean(self, item: str) -> str:
        """영어 item명을 한국어로 변환 (없으면 원래 이름 반환)"""
        return ITEM_KO.get(item, item)

    # ----------------- 물품 리스트 픽업 -----------------
    def bring_items(self, items):
        self.get_logger().info(f"Bringing items: {items}")
        if not items:
            self.get_logger().warn("No items to bring.")
            self.speak("챙길 물품이 없어요.")
            return

        n_goals = len(goals)
        if n_goals == 0:
            self.get_logger().error("goals 리스트가 비어 있습니다. 내려놓을 위치가 없습니다.")
            self.speak("내려놓을 위치가 설정되어 있지 않습니다.")
            return

        for idx, item in enumerate(items):
            goal_idx = idx % n_goals  # items[0]→goals[0], items[1]→goals[1], goals 초과 시 순환
            self.get_logger().info(f"[{item}] will be placed at goals[{goal_idx}] = {goals[goal_idx]}")
            target_pos = self.get_target_pos(item)
            
            if target_pos is None:
                self.get_logger().warn(f"No target position for {item}")
                self.speak(f"{self.get_item_korean(item)}을 찾지 못했습니다.")  # 한국어 변환
            else:
                self.get_logger().info(f"target position for {item}: {target_pos}")
                self.pick_and_place_target(target_pos, goal_idx=goal_idx, target_label=item)
                self.init_robot()
                self.speak(f"{self.get_item_korean(item)} 가져왔어요")  # 한국어 변환
    
    # ----------------- 손위로 물건 전달 -----------------
    def _norm(self, a, b):
        return float(np.linalg.norm(np.array(a) - np.array(b)))

    def deliver_to_hand(self, hand_pos):
        """손 위로 접근 → 살짝 내려가서 놓기 → 상승"""
        if hand_pos is None:
            self.get_logger().warn("deliver_to_hand(): hand_pos is None")
            return False

        # 현재 도구 자세에서 손 위로 접근
        cur = get_current_posx()[0]
        approach = list(cur)
        approach[:3] = [
            hand_pos[0],
            hand_pos[1],
            max(hand_pos[2] + APPROACH_OVERHAND_MM, MIN_DEPTH)
        ]
        movel(approach, vel=VELOCITY, acc=ACC); mwait()

        drop = list(approach)
        drop[2] += DROP_OFFSET_MM
        movel(drop, vel=VELOCITY, acc=ACC); mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.2)

        # 안전 상승
        retreat = list(drop)
        retreat[2] = approach[2]
        movel(retreat, vel=VELOCITY, acc=ACC); mwait()
        return True
    
    def give_me_phone(self):
        """핸드폰 집고, move_to_bucket()으로 고개 들고, J1 회전하며 손(30cm 이내) 감지 시 즉시 전달"""
        # 1) 휴대폰 위치 획득 & 픽업
        phone_pos = self.get_target_pos('phone')
        if phone_pos is None:
            self.get_logger().warn("No target position for phone")
            self.speak("휴대폰을 찾지 못했습니다.")
            return

        # 집기
        pick = list(phone_pos)
        pick[2] -= 20
        movel(pick, vel=VELOCITY, acc=ACC); mwait()
        gripper.close_gripper()
        time.sleep(0.5)

        # 들어올리기
        up = list(pick)
        up[2] += LIFT_AFTER_GRAB_MM
        movel(up, vel=VELOCITY, acc=ACC); mwait()

        # 2) 고개 들기(기존 move_to_bucket 그대로 사용, 수정 금지)
        self.move_to_bucket()

        # 3) 1번 관절만 스윕하면서 손 찾기(30cm 이내면 즉시 전달)
        base_q = list(BUCKET_POS)        
        j1_center = base_q[0]
        start = j1_center - J1_SWEEP_DEG/2
        end   = j1_center + J1_SWEEP_DEG/2
        step  = J1_STEP_DEG if J1_STEP_DEG > 0 else 15

        a = start
        found = False
        while a <= end:
            q = list(base_q); q[0] = a
            movej(q, vel=VELOCITY, acc=ACC); mwait()

            hand_pos = self.get_target_pos('hand')
            if hand_pos is not None:
                tool = get_current_posx()[0]
                d = self._norm(hand_pos[:3], tool[:3])
                self.get_logger().info(f"Hand candidate at {d:.1f} mm (J1={a:.1f}°)")
                if d <= HAND_MAX_DIST_MM:
                    self.speak("전달할게요.")
                    ok = self.deliver_to_hand(hand_pos)
                    if ok:
                        found = True
                    break
            a += step

        if not found:
            self.speak("주변 30센치 이내 손을 찾지 못했어요. 잠시 보관할게요.")
        movej(JREADY, vel=VELOCITY, acc=ACC)

    # ----------------- 전체 메인 함수 격 -----------------
    def robot_control(self):
        self.get_logger().info("call get_keyword service")
        get_keyword_future = self.get_keyword_client.call_async(self.get_keyword_request)
        rclpy.spin_until_future_complete(self, get_keyword_future)

        if get_keyword_future.result().success:
            get_keyword_result = get_keyword_future.result()
            target_list = get_keyword_result.message.split()
            self.get_logger().info(f"Detected target: {target_list}")

            # ✅ target_list 비어있으면 종료
            if not target_list:
                self.get_logger().warn("No task detected (empty target_list).")
                return

            task = target_list[0]            # 0번 → 태스크
            items = target_list[1:]          # 1번 이후 → 챙길 물품들

            # ✅ 우리가 정의한 태스크만 허용
            valid_tasks = ['alarm', '쟈비스', '공부', '학교', '데이트', '핸드폰충전', '핸드폰가져와', '씻고왔어']
            if task not in valid_tasks:
                self.get_logger().warn(f"Unknown task '{task}', skipping.")
                return

            # ---------------- 알람 (물품 없음) ----------------
            if task == 'alarm':
                self.speak("알람을 감지했어요. 어서 일어나세요!")
                self.move_to_bucket()

                skeleton_request = Trigger.Request()
                future = self.skeleton_client.call_async(skeleton_request)
                rclpy.spin_until_future_complete(self, future)

                if future.result() is not None:
                    skeleton_result = future.result()
                    self.get_logger().info(f"skeleton answer: {skeleton_result.message}")
                    self.init_robot()
                    target_pos = self.get_target_pos('phone')
                    if target_pos is None:
                        self.get_logger().warn("No target position")
                        self.speak("대상을 찾지 못했습니다.")
                    else:
                        self.get_logger().info(f"target position: {target_pos}")
                        self.speak("휴대폰 알람 끌께요~")
                        self.off_alarm(target_pos, target_label='phone')
                        self.move_to_bucket()
                        self.speak("아침 스트레칭 시작!")
                        stretching_task = Trigger.Request()
                        future = self.stretching_task.call_async(stretching_task)
                        rclpy.spin_until_future_complete(self, future)
                        if future.result() is not None:
                            self.init_robot()
                            
                else:
                    self.get_logger().warn("Failed to call skeleton_service")
                return

            # ---------------- 쟈비스 ----------------
            elif task == '쟈비스':
                self.speak("네 무엇을 도와드릴까요?")

            # ---------------- 책 ----------------
            elif task == '공부':
                self.speak("공부 준비 해드릴게요")
                self.bring_items(items)
                self.speak("오늘도 화이팅!")

            # ---------------- 학교 ----------------
            elif task == '학교':
                self.speak("학교 갈 준비할게요!")
                self.bring_items(items)
                self.speak("학교 갈 준비 완료!")

            # ---------------- 데이트 ----------------
            elif task == '데이트':
                self.speak("데이트 준비할게요!")
                self.bring_items(items)
                self.speak("데이트 준비 완료!")
            
            elif task == '씻고왔어':
                self.speak("로션 바르세요!")
                self.bring_items(items)
                self.speak("비타민도 챙겨 먹어요!")
            
            elif task == '핸드폰가져와':
                self.speak("조금만 기다리세요!")
                self.give_me_phone()
            
            elif task == '핸드폰충전':
                self.speak("핸드폰 충전 시켜 놓을게요!")
                self.pick_up_charger()

        else:
            self.get_logger().warn(f"{get_keyword_result.message}")
            self.speak("명령 인식에 실패했습니다.", True)
            return

    # ----------------- 물품 위치 획득 -----------------
    def get_target_pos(self, target):
        self.get_position_request.target = target
        self.get_logger().info("call depth position service with object_detection node")
        get_position_future = self.get_position_client.call_async(
            self.get_position_request
        )
        rclpy.spin_until_future_complete(self, get_position_future)

        if get_position_future.result():
            result = get_position_future.result().depth_position.tolist()
            self.get_logger().info(f"Received depth position: {result}")
            if sum(result) == 0:
                print("No target position")
                return None

            gripper2cam_path = os.path.join(package_path, "resource", "T_gripper2camera.npy")
            robot_posx = get_current_posx()[0]
            td_coord = self.transform_to_base(result, gripper2cam_path, robot_posx)

            if td_coord[2] and sum(td_coord) != 0:
                td_coord[2] += DEPTH_OFFSET
                td_coord[2] = max(td_coord[2], MIN_DEPTH)

            target_pos = list(td_coord[:3]) + robot_posx[3:]
            return target_pos
        return None

    # ----------------- 바인딩 박스와 정방향 이미지 각도 확인 후 픽앤플레이스 -----------------
    def pick_and_place_target(self, target_pos, goal_idx, target_label: str = None):

        # [각도 보정] 집기 전 J6 정렬(델타=0.0이면 자동 스킵)
        if target_label:
            delta = self.get_inplane_angle(target_label)
            self.get_logger().info(f"[align] request '{target_label}', delta={delta:.1f}")
            if delta != 0.0:
                curj_raw = get_current_posj()
                self.get_logger().info(f"[align] get_current_posj() raw: {curj_raw}")

                # 정규화
                if hasattr(curj_raw, "tolist"): curj_raw = curj_raw.tolist()
                if isinstance(curj_raw, (list, tuple)) and len(curj_raw) == 6 and all(isinstance(v, (int, float)) for v in curj_raw):
                    q = list(curj_raw)
                elif (isinstance(curj_raw, (list, tuple)) and len(curj_raw) > 0
                    and isinstance(curj_raw[0], (list, tuple)) and len(curj_raw[0]) == 6):
                    q = list(curj_raw[0])
                else:
                    self.get_logger().error("[align] Unexpected get_current_posj() shape; skip")
                    q = None

                if q is not None:
                    q[5] = q[5] + delta
                    self.get_logger().info(f"[align] rotate J6 by {delta:.1f} deg -> target J: {q}")
                    movej(q, vel=30, acc=30); mwait()

                    # ★ 회전 후 현재 rxyz로 target_pos 갱신(다음 movel이 손목을 되돌리지 않도록)
                    curx = get_current_posx()[0]           # [x,y,z,rx,ry,rz]
                    target_pos = list(target_pos)
                    target_pos[3:6] = curx[3:6]

        target_pos[2] -= 20
        if target_label == 'wallet':
            target_pos[2] += 50
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()
        
        pick_up_z = get_current_posx()[0][2]
        gripper.close_gripper()
        time.sleep(0.5)

        target_pos[2] += 200
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()

        while gripper.get_status()[0]:
            time.sleep(0.5)
        
        goals[goal_idx][2] += 200
        # self.get_logger().info(f"Received depth position: {approach_place}")

        movel(goals[goal_idx], vel=VELOCITY, acc=ACC)
        mwait()
        
        goals[goal_idx][2] = pick_up_z + 10
        movel(goals[goal_idx], vel=VELOCITY, acc=ACC)
        mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)

    # ----------------- 알람 끄기 -----------------
    def off_alarm(self, target_pos, target_label: str = None):

        # [각도 보정] 집기 전 J6 정렬(델타=0.0이면 자동 스킵)
        if target_label:
            delta = self.get_inplane_angle(target_label)
            self.get_logger().info(f"[align] request '{target_label}', delta={delta:.1f}")
            if delta != 0.0:
                curj_raw = get_current_posj()
                self.get_logger().info(f"[align] get_current_posj() raw: {curj_raw}")

                # 정규화
                if hasattr(curj_raw, "tolist"): curj_raw = curj_raw.tolist()
                if isinstance(curj_raw, (list, tuple)) and len(curj_raw) == 6 and all(isinstance(v, (int, float)) for v in curj_raw):
                    q = list(curj_raw)
                elif (isinstance(curj_raw, (list, tuple)) and len(curj_raw) > 0
                    and isinstance(curj_raw[0], (list, tuple)) and len(curj_raw[0]) == 6):
                    q = list(curj_raw[0])
                else:
                    self.get_logger().error("[align] Unexpected get_current_posj() shape; skip")
                    q = None

                if q is not None:
                    q[5] = q[5] + delta
                    self.get_logger().info(f"[align] rotate J6 by {delta:.1f} deg -> target J: {q}")
                    movej(q, vel=30, acc=30); mwait()

                    # ★ 회전 후 현재 rxyz로 target_pos 갱신(다음 movel이 손목을 되돌리지 않도록)
                    curx = get_current_posx()[0]           # [x,y,z,rx,ry,rz]
                    target_pos = list(target_pos)
                    target_pos[3:6] = curx[3:6]

        target_pos[2] -= 20
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()
        
        gripper.close_gripper()
        time.sleep(0.5)

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)

    # ----------------- 핸드폰 충전 패드 위로 이동 -----------------
    def charger_phone(self, target_pos, target_label: str = None):

        # [각도 보정] 집기 전 J6 정렬(델타=0.0이면 자동 스킵)
        if target_label:
            delta = self.get_inplane_angle(target_label)
            self.get_logger().info(f"[align] request '{target_label}', delta={delta:.1f}")
            if delta != 0.0:
                curj_raw = get_current_posj()
                self.get_logger().info(f"[align] get_current_posj() raw: {curj_raw}")

                # 정규화
                if hasattr(curj_raw, "tolist"): curj_raw = curj_raw.tolist()
                if isinstance(curj_raw, (list, tuple)) and len(curj_raw) == 6 and all(isinstance(v, (int, float)) for v in curj_raw):
                    q = list(curj_raw)
                elif (isinstance(curj_raw, (list, tuple)) and len(curj_raw) > 0
                    and isinstance(curj_raw[0], (list, tuple)) and len(curj_raw[0]) == 6):
                    q = list(curj_raw[0])
                else:
                    self.get_logger().error("[align] Unexpected get_current_posj() shape; skip")
                    q = None

                if q is not None:
                    q[5] = q[5] + delta
                    self.get_logger().info(f"[align] rotate J6 by {delta:.1f} deg -> target J: {q}")
                    movej(q, vel=30, acc=30); mwait()

                    # ★ 회전 후 현재 rxyz로 target_pos 갱신(다음 movel이 손목을 되돌리지 않도록)
                    curx = get_current_posx()[0]           # [x,y,z,rx,ry,rz]
                    target_pos = list(target_pos)
                    target_pos[3:6] = curx[3:6]

        target_pos[2] -= 20
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()
        
        gripper.close_gripper()
        time.sleep(0.5)

        target_pos[2] += 100
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()

        movel(CHARGER_PAD, vel=VELOCITY, acc=ACC)
        mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)

    # ----------------- 충전기 픽업 및 꽂아두기 -----------------
    def pick_up_charger(self):
        movel(CHARGER_POS, vel=VELOCITY, acc=ACC)
        gripper.close_gripper()
        time.sleep(0.5)

        pick_up_z = get_current_posx()[0]
        pick_up_z[2] += 100
        movel(pick_up_z, vel=VELOCITY, acc=ACC)
        mwait()

        movej([0.0, 0.0, 90.0, 0.0, 90.0, 0.0], vel=VELOCITY, acc=ACC)
        mwait()

        time.sleep(2)

        # ---- 공용 파서 (로컬 함수) ----
        def _call_outlet_xyz(timeout_sec: float = 5.0):
            if not self.outlet_client.wait_for_service(timeout_sec=1.0):
                self.get_logger().warn("outlet/get_base_xyz not available.")
                return None, "unavailable"
            req = Trigger.Request()
            fut = self.outlet_client.call_async(req)
            rclpy.spin_until_future_complete(self, fut, timeout_sec=timeout_sec)
            res = fut.result()
            if (res is None) or (not res.success):
                return None, (res.message if res else "no response")
            msg = (res.message or "").strip()
            parts = msg.replace(",", " ").split()
            if len(parts) < 3:
                return None, f"bad message: '{msg}'"
            try:
                x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                return (x, y, z), None
            except Exception as e:
                return None, f"parse error: {e}"

        # 1) 첫 측정 → 현재 Z 그대로 두고 XY만 정렬
        xyz, err = _call_outlet_xyz()
        if xyz is None:
            self.get_logger().warn(f"outlet/get_base_xyz failed: {err}")
            return

        tx, ty, tz = xyz
        self.get_logger().info(f"[outlet] base xyz (mm): x={tx:.1f}, y={ty:.1f}, z={tz:.1f}")

        curx = get_current_posx()[0]        # [x,y,z,rx,ry,rz]
        target = list(curx)
        target[0] = tx
        target[1] = ty
        
        # Z는 그대로(현재 높이 유지)
        movel(target, vel=VELOCITY, acc=ACC); mwait()
        mwait()

        target[3] -= 45
        time.sleep(1)
        movel(target, vel=VELOCITY, acc=ACC); mwait()
        mwait()

        # 2) 단계적 하강/정렬:
        #   - phase 0 (이미 수행): XY 정렬(현재 Z 유지)
        #   - phase 1 (k == 0):  X 고정 + (Z 한 스텝 하강) + Y 정렬
        #   - phase 2+ (k >= 1): X 고정 + Y만 미세 정렬
        MAX_ITERS         = 3
        Z_STEP            = 15.0   # 매 스텝 하강 mm
        APPROACH_Z_OFFSET = 25.0   # 목표 z보다 위에서 멈춤(충돌 방지)
        Y_TOL             = 2.0    # y 수렴 기준 (mm)
        Z_TOL             = 2.0    # z 수렴 기준 (mm)
        XY_LIMIT          = 2000.0
        Z_LIMIT           = 2000.0

        # 첫 XY 정렬 이후의 '고정 X'는 현재 위치 X로 확정
        lock_x = get_current_posx()[0][0]

        for k in range(MAX_ITERS):
            time.sleep(1)  # 카메라 갱신 여유

            xyz, err = _call_outlet_xyz()
            if xyz is None:
                self.get_logger().warn(f"[iter {k}] outlet/get_base_xyz failed: {err}")
                break

            tx, ty, tz = xyz
            if any([abs(tx) > XY_LIMIT, abs(ty) > XY_LIMIT, (tz < -Z_LIMIT), (tz > Z_LIMIT)]):
                self.get_logger().warn(f"[iter {k}] ignore outlier xyz: {xyz}")
                break

            # 현재 포즈
            curx = get_current_posx()[0]
            cx, cy, cz = curx[0], curx[1], curx[2]

            # 목표 Z는 항상 '접근 오프셋'만큼 위에서 멈추기
            target_z = max(tz + APPROACH_Z_OFFSET, MIN_DEPTH)

            # 이동 목표 초기화: X는 'lock_x'로 고정
            next_pos = list(curx)
            next_pos[0] = lock_x

            if k == 0:
                # 1회차: Z를 한 스텝 내리면서, Y는 측정값으로 정렬
                next_pos[1] = ty
                # Z는 한 스텝만 내리기(너무 급하강 방지)
                if cz - target_z > Z_STEP:
                    next_pos[2] = cz - Z_STEP
                else:
                    next_pos[2] = target_z

                self.get_logger().info(
                    f"[iter {k}] (X lock) Y→{next_pos[1]:.1f}, Z step→{next_pos[2]:.1f} "
                    f"(cur z={cz:.1f}, target z={target_z:.1f})"
                )
                movel(next_pos, vel=VELOCITY, acc=ACC); mwait()
                continue

            # k >= 1: 이후부터는 Y만 미세 정렬
            dy = ty - cy
            if abs(dy) <= Y_TOL and abs(cz - target_z) <= Z_TOL:
                self.get_logger().info(f"[iter {k}] reached tolerance: |Y|≤{Y_TOL}mm, |Z|≤{Z_TOL}mm")
                break

            # Y만 맞추고, Z는 필요 시만 한 스텝 보정(선택)
            next_pos[1] = ty
            # Z는 이미 충분히 근접했으면 유지, 아니면 한 스텝(선택)
            if abs(cz - target_z) > Z_TOL:
                if cz - target_z > Z_STEP:
                    next_pos[2] = cz - Z_STEP
                elif target_z - cz > Z_STEP:
                    next_pos[2] = cz + Z_STEP
                else:
                    next_pos[2] = target_z
            # else: next_pos[2] = cz (변경 없음)

            self.get_logger().info(
                f"[iter {k}] (X lock) Y→{next_pos[1]:.1f} "
                f"{'(Z step)' if abs(cz - target_z) > Z_TOL else '(Z hold)'} "
                f"→ z={next_pos[2]:.1f}"
            )
            movel(next_pos, vel=VELOCITY, acc=ACC); mwait()
        
        movel(CHARGER_POS_FINAL, vel=VELOCITY, acc=ACC)
        mwait()
        time.sleep(0.5)
        print("set_desired_force1")
        task_compliance_ctrl(stx=[50, 50, 50, 100, 100, 100])
        time.sleep(0.2)
        set_desired_force(fd = [0,0,-70,0,0,0],dir = [0,0,1,0,0,0],mod=DR_FC_MOD_REL)
        while not check_force_condition(DR_AXIS_Z,max=20):
            time.sleep(0.5)
            release_force
        release_compliance_ctrl()

        time.sleep(0.5)
        gripper.open_gripper()

        self.init_robot()

        target_pos = self.get_target_pos('phone')
        self.charger_phone(target_pos, target_label='phone')

        self.init_robot()

def main(args=None):
    node = RobotController()
    while rclpy.ok():
        node.robot_control()
    rclpy.shutdown()
    node.destroy_node()


if __name__ == "__main__":
    main()
