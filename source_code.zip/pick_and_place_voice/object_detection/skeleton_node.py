# # object_detection/yolo_skeleton_service.py
# import os, math, collections, time
# import numpy as np
# import cv2
# from ultralytics import YOLO
# from ament_index_python.packages import get_package_share_directory
# import rclpy
# from rclpy.node import Node
# from std_srvs.srv import Trigger

# # -------- Config --------
# PACKAGE_NAME = "pick_and_place_voice"
# PACKAGE_PATH = get_package_share_directory(PACKAGE_NAME)
# MODEL = "yolo11n-pose.pt"
# YOLO_MODEL_PATH = os.path.join(PACKAGE_PATH, "resource", MODEL)

# IMG_SIZE = 640
# DEVICE = os.environ.get("DEVICE", "cpu")  # "cpu" or GPU index like "0"
# QUEUE = 15
# STABLE_RATIO = 0.7
# WAKE_HOLD = 0.8

# # 이진 분류 임계값
# SIT_T = 60.0   # deg
# AR_SIT = 0.95

# # 색/스타일
# UPPER_COLOR = (0, 255, 255)
# LOWER_COLOR = (255, 0, 255)
# JOINT_COLOR = (255, 255, 255)
# LINE_THICK = 3
# DOT_RADIUS = 4

# # Keypoint idx
# NOSE=0; L_SH=5; R_SH=6; L_HIP=11; R_HIP=12; L_KNEE=13; R_KNEE=14; L_ANK=15; R_ANK=16

# def midpoint(a, b): return ((a[0]+b[0])/2.0, (a[1]+b[1])/2.0)

# def angle_to_vertical(p1, p2):
#     vx, vy = p2[0]-p1[0], p2[1]-p1[1]
#     vnorm = math.hypot(vx, vy)
#     if vnorm < 1e-6: return None
#     cosv = max(-1.0, min(1.0, vy / vnorm))
#     return math.degrees(math.acos(cosv))  # 0=수직

# def bbox_from_keypoints(kps):
#     xs = [x for x,y in kps if x>0 and y>0]
#     ys = [y for x,y in kps if x>0 and y>0]
#     if not xs or not ys: return None
#     return (min(xs), min(ys), max(xs), max(ys))

# def _line_sample(p1, p2, t=0.5):
#     return (p1[0]*(1-t)+p2[0]*t, p1[1]*(1-t)+p2[1]*t)

# def extract_line_points(kps, belly_t=0.5):
#     def ok(idx): return not (kps[idx][0]==0 and kps[idx][1]==0)
#     pts = {}
#     if ok(NOSE): pts["head"] = (float(kps[NOSE][0]), float(kps[NOSE][1]))
#     if ok(L_SH) and ok(R_SH):
#         chest = midpoint(kps[L_SH], kps[R_SH]); pts["chest"] = (float(chest[0]), float(chest[1]))
#     if ok(L_HIP) and ok(R_HIP):
#         pelvis = midpoint(kps[L_HIP], kps[R_HIP]); pts["pelvis"] = (float(pelvis[0]), float(pelvis[1]))
#     if ok(L_KNEE) and ok(R_KNEE):
#         knee = midpoint(kps[L_KNEE], kps[R_KNEE]); pts["knee"] = (float(knee[0]), float(knee[1]))
#     if ok(L_ANK) and ok(R_ANK):
#         foot = midpoint(kps[L_ANK], kps[R_ANK]); pts["foot"] = (float(foot[0]), float(foot[1]))
#     if "chest" in pts and "pelvis" in pts:
#         belly = _line_sample(pts["chest"], pts["pelvis"], t=belly_t)
#         pts["belly"] = (float(belly[0]), float(belly[1]))
#     return pts

# def draw_color_skeleton(img, pts):
#     upper = ["head","chest","belly","pelvis"]
#     lower = ["pelvis","knee","foot"]
#     for name in set(upper+lower):
#         if name in pts:
#             cv2.circle(img, (int(pts[name][0]), int(pts[name][1])), DOT_RADIUS, JOINT_COLOR, -1)
#     def draw_chain(chain, color):
#         chain_xy = [pts[n] for n in chain if n in pts]
#         for i in range(len(chain_xy)-1):
#             p, q = chain_xy[i], chain_xy[i+1]
#             cv2.line(img, (int(p[0]), int(p[1])), (int(q[0], ), int(q[1])), color, LINE_THICK)
#     draw_chain(upper, UPPER_COLOR)
#     draw_chain(lower, LOWER_COLOR)
#     return img

# def classify_wakeup_fast(kps, img_shape):
#     pts = kps.astype(float)
#     zero = lambda p: np.all(p==0)
#     if zero(pts[L_SH]) or zero(pts[R_SH]) or zero(pts[L_HIP]) or zero(pts[R_HIP]):
#         return "unknown", 0.0
#     shoulder_mid = midpoint(pts[L_SH], pts[R_SH])
#     hip_mid      = midpoint(pts[L_HIP], pts[R_HIP])
#     theta_torso  = angle_to_vertical(shoulder_mid, hip_mid)
#     bb = bbox_from_keypoints(pts)
#     ar = None
#     if bb:
#         x1,y1,x2,y2 = bb
#         w = max(x2-x1, 1e-6); h = max(y2-y1, 1e-6)
#         ar = h / w
#     if theta_torso is not None and theta_torso <= SIT_T:
#         conf = float(np.clip(1.0 - theta_torso / SIT_T, 0.4, 1.0))
#         return "wake up", conf
#     if (theta_torso is not None) and (ar is not None) and (theta_torso <= 75.0) and (ar >= AR_SIT):
#         return "wake up", 0.55
#     conf = 0.4
#     if theta_torso is not None:
#         conf = float(np.clip((theta_torso - SIT_T) / (90.0 - SIT_T), 0.4, 0.95))
#     return "sleeping", conf

# def _open_capture_from_env():
#     """6번 카메라 사용 (필요 시 인덱스만 바꾸세요)"""
#     cap = cv2.VideoCapture(8, cv2.CAP_V4L2)  # 실행만 맞추기: V4L2 명시
#     if not cap.isOpened():
#         print("[ERR] Cannot open camera index 8")
#         return None
#     # 실행 안정성: 컬러 변환/포맷 지정 (원 코드 로직은 보존)
#     cap.set(cv2.CAP_PROP_CONVERT_RGB, 1)
#     cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
#     cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
#     cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
#     cap.set(cv2.CAP_PROP_FPS, 30)
#     return cap

# # ---------------- ROS2 Node ----------------
# class SkeletonMonitor(Node):
#     def __init__(self):
#         super().__init__("skeleton_monitor")
#         self.skeleton_service_srv = self.create_service(
#             Trigger, "skeleton_service", self.sit_up_callback
#         )
#         # 모델을 여기서 한 번만 로드하면 속도가 조금 더 안정적
#         self.model = YOLO(YOLO_MODEL_PATH)

#     def sit_up_callback(self, request, response):
#         cap = _open_capture_from_env()
#         if cap is None or (not cap.isOpened()):
#             self.get_logger().error("Camera open failed")
#             response.success = False
#             response.message = "camera_open_failed"
#             return response

#         q = collections.deque(maxlen=QUEUE)
#         stable_state = "unknown"
#         prev_stable_state = "unknown"
#         event_armed = False
#         event_target = None
#         event_start_t = None

#         try:
#             while rclpy.ok():
#                 ok, frame = cap.read()
#                 if not ok or frame is None:
#                     self.get_logger().warn("Frame read failed")
#                     response.success = False
#                     response.message = "frame_error"
#                     return response

#                 # 원 코드 유지: (단, 모델은 self.model 사용)
#                 res = self.model(frame, imgsz=IMG_SIZE, device=DEVICE, verbose=False)[0]

#                 if (res.keypoints is None) or (len(res.keypoints) == 0):
#                     q.append("unknown")
#                 else:
#                     if (res.boxes is not None) and (len(res.boxes) > 0):
#                         areas = (res.boxes.xywh[:,2] * res.boxes.xywh[:,3]).cpu().numpy()
#                         idx = int(np.argmax(areas))
#                     else:
#                         idx = 0
#                     kps = res.keypoints.xy[idx].cpu().numpy()
#                     label, conf = classify_wakeup_fast(kps, frame.shape)
#                     q.append(label)

#                     # 원 코드의 스켈레톤 그리기 유지 (GUI 사용)
#                     pts = extract_line_points(kps, belly_t=0.5)
#                     frame = draw_color_skeleton(frame, pts)

#                 counts = collections.Counter(q)
#                 current = counts.most_common(1)[0][0]
#                 now = time.time()

#                 if len(q) == QUEUE and counts[current] >= int(STABLE_RATIO*QUEUE) and current != stable_state:
#                     prev_stable_state = stable_state
#                     stable_state = current
#                     if prev_stable_state == "sleeping" and stable_state == "wake up":
#                         event_armed = True
#                         event_target = stable_state
#                         event_start_t = now
#                     else:
#                         event_armed = False
#                         event_target = None
#                         event_start_t = None

#                 sit_up_event = False
#                 if event_armed and event_target == stable_state and (now - event_start_t >= WAKE_HOLD):
#                     if event_target == "wake up":
#                         sit_up_event = True
#                         self.get_logger().info("SIT UP detected! Service responding.")
#                         response.success = True
#                         response.message = "sit_up"
#                         return response
#                     event_armed = False

#                 # 화면 출력(원 코드 유지)
#                 cv2.putText(frame, f"State: {stable_state}", (20,40),
#                             cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 2)
#                 if sit_up_event:
#                     cv2.putText(frame, "SIT UP!", (20,80),
#                                 cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,165,255), 3)
#                 cv2.imshow("Posture Monitor", frame)
#                 if cv2.waitKey(1) & 0xFF == ord('q'):
#                     self.get_logger().info("User pressed q")
#                     response.success = False
#                     response.message = "user_quit"
#                     return response

#         finally:
#             # 어떤 경로로든 빠져나갈 때 자원 정리 + 창 닫기
#             try:
#                 cap.release()
#             except Exception:
#                 pass
#             try:
#                 cv2.destroyAllWindows()
#                 cv2.waitKey(1)
#             except Exception:
#                 pass

#         # 루프를 자연 종료한 경우(이론상 도달X)도 안전하게 반환
#         response.success = False
#         response.message = "no_event"
#         return response

# # ---------------- Main ----------------
# def main(args=None):
#     rclpy.init(args=args)
#     node = SkeletonMonitor()
#     try:
#         rclpy.spin(node)  # ✅ node.run() 아님!
#     except KeyboardInterrupt:
#         pass
#     finally:
#         if rclpy.ok():
#             rclpy.shutdown()
#         node.destroy_node()

# if __name__ == "__main__":
#     main()

# object_detection/yolo_skeleton_service.py
import os, math, collections, time
import numpy as np
import cv2
from ultralytics import YOLO
from ament_index_python.packages import get_package_share_directory

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from std_srvs.srv import Trigger

# RealSense ImgNode 가져오기
from object_detection.realsense import ImgNode

# -------- Config --------
PACKAGE_NAME = "pick_and_place_voice"
PACKAGE_PATH = get_package_share_directory(PACKAGE_NAME)
MODEL = "yolo11n-pose.pt"
YOLO_MODEL_PATH = os.path.join(PACKAGE_PATH, "resource", MODEL)

IMG_SIZE = 640
DEVICE = os.environ.get("DEVICE", "cpu")  # "cpu" or GPU index like "0"
QUEUE = 15
STABLE_RATIO = 0.7
WAKE_HOLD = 0.8

# 이진 분류 임계값
SIT_T = 60.0   # deg
AR_SIT = 0.95

# 색/스타일
UPPER_COLOR = (0, 255, 255)
LOWER_COLOR = (255, 0, 255)
JOINT_COLOR = (255, 255, 255)
LINE_THICK = 3
DOT_RADIUS = 4

# Keypoint idx (COCO)
NOSE=0; L_SH=5; R_SH=6; L_HIP=11; R_HIP=12; L_KNEE=13; R_KNEE=14; L_ANK=15; R_ANK=16

# ---------- Utils ----------
def midpoint(a, b): 
    return ((a[0]+b[0])/2.0, (a[1]+b[1])/2.0)

def angle_to_vertical(p1, p2):
    vx, vy = p2[0]-p1[0], p2[1]-p1[1]
    vnorm = math.hypot(vx, vy)
    if vnorm < 1e-6: 
        return None
    # 화면 y축이 아래로 증가하는 좌표에서, 수직 방향은 +y
    cosv = max(-1.0, min(1.0, vy / vnorm))
    return math.degrees(math.acos(cosv))  # 0=수직, 90=수평

def bbox_from_keypoints(kps):
    xs = [x for x,y in kps if x>0 and y>0]
    ys = [y for x,y in kps if x>0 and y>0]
    if not xs or not ys: 
        return None
    return (min(xs), min(ys), max(xs), max(ys))

def _line_sample(p1, p2, t=0.5):
    return (p1[0]*(1-t)+p2[0]*t, p1[1]*(1-t)+p2[1]*t)

def extract_line_points(kps, belly_t=0.5):
    def ok(idx): 
        return not (kps[idx][0]==0 and kps[idx][1]==0)
    pts = {}
    if ok(NOSE): 
        pts["head"] = (float(kps[NOSE][0]), float(kps[NOSE][1]))
    if ok(L_SH) and ok(R_SH):
        chest = midpoint(kps[L_SH], kps[R_SH]); 
        pts["chest"] = (float(chest[0]), float(chest[1]))
    if ok(L_HIP) and ok(R_HIP):
        pelvis = midpoint(kps[L_HIP], kps[R_HIP]); 
        pts["pelvis"] = (float(pelvis[0]), float(pelvis[1]))
    if ok(L_KNEE) and ok(R_KNEE):
        knee = midpoint(kps[L_KNEE], kps[R_KNEE]); 
        pts["knee"] = (float(knee[0]), float(knee[1]))
    if ok(L_ANK) and ok(R_ANK):
        foot = midpoint(kps[L_ANK], kps[R_ANK]); 
        pts["foot"] = (float(foot[0]), float(foot[1]))
    if "chest" in pts and "pelvis" in pts:
        belly = _line_sample(pts["chest"], pts["pelvis"], t=belly_t)
        pts["belly"] = (float(belly[0]), float(belly[1]))
    return pts

def draw_color_skeleton(img, pts):
    upper = ["head","chest","belly","pelvis"]
    lower = ["pelvis","knee","foot"]
    for name in set(upper+lower):
        if name in pts:
            cv2.circle(img, (int(pts[name][0]), int(pts[name][1])), DOT_RADIUS, JOINT_COLOR, -1)
    def draw_chain(chain, color):
        chain_xy = [pts[n] for n in chain if n in pts]
        for i in range(len(chain_xy)-1):
            p, q = chain_xy[i], chain_xy[i+1]
            cv2.line(img, (int(p[0]), int(p[1])), (int(q[0]), int(q[1])), color, LINE_THICK)
    draw_chain(upper, UPPER_COLOR)
    draw_chain(lower, LOWER_COLOR)
    return img

def classify_wakeup_fast(kps, img_shape):
    pts = kps.astype(float)
    zero = lambda p: np.all(p==0)
    if zero(pts[L_SH]) or zero(pts[R_SH]) or zero(pts[L_HIP]) or zero(pts[R_HIP]):
        return "unknown", 0.0

    shoulder_mid = midpoint(pts[L_SH], pts[R_SH])
    hip_mid      = midpoint(pts[L_HIP], pts[R_HIP])
    theta_torso  = angle_to_vertical(shoulder_mid, hip_mid)  # 0=수직

    bb = bbox_from_keypoints(pts)
    ar = None
    if bb:
        x1,y1,x2,y2 = bb
        w = max(x2-x1, 1e-6); h = max(y2-y1, 1e-6)
        ar = h / w

    # 선자세(일어남) 판단
    if theta_torso is not None and theta_torso <= SIT_T:
        conf = float(np.clip(1.0 - theta_torso / SIT_T, 0.4, 1.0))
        return "wake up", conf

    # 보정 규칙(세워진 듯 보이는 케이스)
    if (theta_torso is not None) and (ar is not None) and (theta_torso <= 75.0) and (ar >= AR_SIT):
        return "wake up", 0.55

    # 기본: 자는 상태
    conf = 0.4
    if theta_torso is not None:
        conf = float(np.clip((theta_torso - SIT_T) / (90.0 - SIT_T), 0.4, 0.95))
    return "sleeping", conf

# ---------------- ROS2 Node ----------------
class SkeletonMonitor(Node):
    def __init__(self):
        super().__init__("skeleton_monitor")
        self.skeleton_service_srv = self.create_service(
            Trigger, "skeleton_service", self.sit_up_callback
        )
        # YOLO Pose 모델 로드 (한 번만)
        self.model = YOLO(YOLO_MODEL_PATH)

        # RealSense 이미지 노드
        self.img_node = ImgNode()

        # 디버그 옵션 (파라미터로 제어 가능)
        self.declare_parameter('show_window', True)
        self.show_window = bool(self.get_parameter('show_window').value)

    def _get_latest_frame(self, timeout_sec: float = 1.0):
        """
        ImgNode에서 최신 컬러 프레임 하나를 가져온다.
        필요 시 spin_once로 콜백 처리 기회 제공.
        """
        t0 = time.time()
        frame = self.img_node.get_color_frame()
        while frame is None and (time.time() - t0) < timeout_sec and rclpy.ok():
            # ImgNode 콜백 처리
            rclpy.spin_once(self.img_node, timeout_sec=0.01)
            frame = self.img_node.get_color_frame()
        return frame

    def sit_up_callback(self, request, response):
        q = collections.deque(maxlen=QUEUE)
        stable_state = "unknown"
        prev_stable_state = "unknown"
        event_armed = False
        event_target = None
        event_start_t = None

        try:
            while rclpy.ok():
                frame = self._get_latest_frame(timeout_sec=1.0)
                if frame is None:
                    self.get_logger().warn("No frame from RealSense")
                    response.success = False
                    response.message = "frame_timeout"
                    return response

                # YOLO Pose (self.model은 미리 로딩한 모델)
                res = self.model(frame, imgsz=IMG_SIZE, device=DEVICE, verbose=False)[0]

                if (res.keypoints is None) or (len(res.keypoints) == 0):
                    q.append("unknown")
                else:
                    # 가장 큰 사람 선택
                    if (res.boxes is not None) and (len(res.boxes) > 0):
                        areas = (res.boxes.xywh[:,2] * res.boxes.xywh[:,3]).cpu().numpy()
                        idx = int(np.argmax(areas))
                    else:
                        idx = 0
                    kps = res.keypoints.xy[idx].cpu().numpy()
                    label, conf = classify_wakeup_fast(kps, frame.shape)
                    q.append(label)

                    # 시각화 (선택)
                    pts = extract_line_points(kps, belly_t=0.5)
                    if self.show_window:
                        frame = draw_color_skeleton(frame, pts)

                counts = collections.Counter(q)
                current = counts.most_common(1)[0][0]
                now = time.time()

                # 안정 상태 업데이트
                if len(q) == QUEUE and counts[current] >= int(STABLE_RATIO*QUEUE) and current != stable_state:
                    prev_stable_state = stable_state
                    stable_state = current
                    if prev_stable_state == "sleeping" and stable_state == "wake up":
                        event_armed = True
                        event_target = stable_state
                        event_start_t = now
                    else:
                        event_armed = False
                        event_target = None
                        event_start_t = None

                # 이벤트 홀드 판정
                sit_up_event = False
                if event_armed and event_target == stable_state and (now - event_start_t >= WAKE_HOLD):
                    if event_target == "wake up":
                        sit_up_event = True
                        self.get_logger().info("SIT UP detected! Service responding.")
                        response.success = True
                        response.message = "sit_up"
                        return response
                    event_armed = False

                # 디스플레이
                if self.show_window:
                    cv2.putText(frame, f"State: {stable_state}", (20,40),
                                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 2)
                    if sit_up_event:
                        cv2.putText(frame, "SIT UP!", (20,80),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,165,255), 3)
                    cv2.imshow("Posture Monitor (RealSense)", frame)
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        self.get_logger().info("User pressed q")
                        response.success = False
                        response.message = "user_quit"
                        return response

        finally:
            try:
                if self.show_window:
                    cv2.destroyAllWindows()
                    cv2.waitKey(1)
            except Exception:
                pass

        # (이론상 도달X) 안전 반환
        response.success = False
        response.message = "no_event"
        return response

# ---------------- Main ----------------
def main(args=None):
    rclpy.init(args=args)
    node = SkeletonMonitor()

    # ImgNode와 서비스 노드를 함께 돌리기(프레임 콜백 처리)
    exec = MultiThreadedExecutor(num_threads=2)
    exec.add_node(node)          # 서비스/로직
    exec.add_node(node.img_node) # RealSense 프레임 수신

    try:
        exec.spin()
    except KeyboardInterrupt:
        pass
    finally:
        exec.shutdown()
        node.destroy_node()
        node.img_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()

