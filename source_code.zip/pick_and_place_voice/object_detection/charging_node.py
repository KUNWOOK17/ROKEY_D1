#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, math, time
from typing import Tuple, Optional
import numpy as np
import cv2
import DR_init

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from std_srvs.srv import Trigger

# 🔸 ImgNode를 직접 사용 (토픽 구독 X)
from object_detection.realsense import ImgNode

# ====== (옵션) Doosan DSR SDK - 있으면 사용 ======
# for single robot
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

rclpy.init()
dsr_node = rclpy.create_node("charger_node", namespace=ROBOT_ID)
DR_init.__dsr__node = dsr_node

try:
    from DSR_ROBOT2 import get_current_posx
except ImportError as e:
    print(f"Error importing DSR_ROBOT2: {e}")

# ===== 파라미터 기본값 =====
RESIZE_SCALE   = 0.8
PIN_DIST_MM    = 19.0
PAIR_TOL_RATIO = 0.05
MAX_ATTEMPTS   = 60
WAIT_TIMEOUT_S = 1.0

# Blob 파라미터
BLOB_MIN_AREA    = 12
BLOB_MAX_AREA    = 1500
BLOB_MIN_CIRC    = 0.55
BLOB_MIN_INERTIA = 0.35

# 보정행렬 후보
T_G2C_CANDIDATES = [
    "/home/rokey/ros2_ws/src/DoosanBootcamp3rd/dsr_rokey/pick_and_place_voice/resource/T_gripper2camera.npy"
]

# ===== 유틸 =====
def divide_by_blur(gray: np.ndarray, k: int = 15) -> np.ndarray:
    blur = cv2.blur(gray, (k, k))
    return cv2.divide(gray, blur, scale=255)

def simpleblob_centers(binary: np.ndarray,
                       ref_xy: tuple[float,float] | None = None,
                       roi: tuple[int,int,int,int] | None = None,
                       radius: float | None = None,
                       k: int | None = None) -> np.ndarray:
    params = cv2.SimpleBlobDetector_Params()
    params.filterByColor = True;  params.blobColor = 255
    params.filterByArea  = True;  params.minArea = BLOB_MIN_AREA; params.maxArea = BLOB_MAX_AREA
    params.filterByCircularity = True; params.minCircularity = BLOB_MIN_CIRC
    params.filterByInertia = True; params.minInertiaRatio = BLOB_MIN_INERTIA
    params.filterByConvexity = False
    det = cv2.SimpleBlobDetector_create(params)

    if roi is not None:
        x0, y0, x1, y1 = roi
        x0 = max(0, x0); y0 = max(0, y0)
        x1 = min(binary.shape[1], x1); y1 = min(binary.shape[0], y1)
        if x1 <= x0 or y1 <= y0:
            return np.empty((0, 2), np.float32)
        bin_crop = binary[y0:y1, x0:x1]
        kps = det.detect(bin_crop)
        pts = np.array([[kp.pt[0] + x0, kp.pt[1] + y0] for kp in kps], dtype=np.float32)
    else:
        kps = det.detect(binary)
        pts = np.array([kp.pt for kp in kps], dtype=np.float32)

    if pts.shape[0] == 0 or ref_xy is None:
        return pts

    if k is None:
        k = 2
    rx, ry = ref_xy
    if radius is not None:
        r2 = radius * radius
        mask = ((pts[:,0]-rx)**2 + (pts[:,1]-ry)**2) <= r2
        pts = pts[mask]
        if pts.shape[0] == 0:
            return np.empty((0, 2), np.float32)

    d2 = (pts[:,0]-rx)**2 + (pts[:,1]-ry)**2
    order = np.argsort(d2)[:k]
    return pts[order]

def hough_centers(gray_small: np.ndarray) -> np.ndarray:
    g = cv2.GaussianBlur(gray_small, (7,7), 1.5)
    cir = cv2.HoughCircles(g, cv2.HOUGH_GRADIENT, dp=1.2, minDist=14,
                           param1=120, param2=10, minRadius=3, maxRadius=18)
    if cir is None: return np.empty((0,2), np.float32)
    return cir[0,:,:2].astype(np.float32)

def median_depth_m(depth_m: np.ndarray, px: Tuple[float,float], patch: int = 2) -> Optional[float]:
    x, y = int(round(px[0])), int(round(px[1]))
    h, w = depth_m.shape
    if not (0 <= x < w and 0 <= y < h):
        return None
    x0, x1 = max(0, x-patch), min(w, x+patch+1)
    y0, y1 = max(0, y-patch), min(h, y+patch+1)
    p = depth_m[y0:y1, x0:x1]
    p = p[p > 0]
    if p.size == 0:
        return None
    return float(np.median(p))

def expected_px_distance(fx: float, z_mm: float) -> float:
    z = max(z_mm, 1e-3)
    return fx * (PIN_DIST_MM / z)

def pixel_to_cam3D(pix, Z_m, fx, fy, ppx, ppy) -> np.ndarray:
    x = (pix[0] - ppx) * Z_m / fx
    y = (pix[1] - ppy) * Z_m / fy
    return np.array([x, y, Z_m], dtype=np.float64)

def Rz(deg):
    r = math.radians(deg); c,s = math.cos(r), math.sin(r)
    return np.array([[c,-s,0],[s,c,0],[0,0,1]], dtype=np.float64)

def Ry(deg):
    r = math.radians(deg); c,s = math.cos(r), math.sin(r)
    return np.array([[c,0,s],[0,1,0],[-s,0,c]], dtype=np.float64)

def euler_ZYZ_to_R(z1_deg, y_deg, z2_deg):
    return Rz(z1_deg) @ Ry(y_deg) @ Rz(z2_deg)

def get_base2gripper_T_from_posx(posx6) -> np.ndarray:
    x,y,z, rz1, ry, rz2 = posx6
    R = euler_ZYZ_to_R(rz1, ry, rz2)
    T = np.eye(4); T[:3,:3] = R; T[:3,3] = [x, y, z]  # mm
    return T

def load_T_g2c(logger=None) -> Optional[np.ndarray]:
    for p in T_G2C_CANDIDATES:
        if os.path.exists(p):
            try:
                T = np.load(p)
                if T.shape == (4,4):
                    (logger.info if logger else print)(f"[INFO] Loaded T_gripper2camera: {p}")
                    return T.astype(np.float64)
            except Exception as e:
                (logger.warn if logger else print)(f"[WARN] Failed to load {p}: {e}")
    (logger.warn if logger else print)("T_gripper2camera.npy not found. BASE transform disabled.")
    return None

class OutletDetectSrvNode(Node):
    def __init__(self):
        super().__init__("outlet_detect_srv")

        # 파라미터
        self.declare_parameter("resize_scale", RESIZE_SCALE)
        self.declare_parameter("pair_tol_ratio", PAIR_TOL_RATIO)
        self.declare_parameter("use_dark_map", True)
        self.resize_scale = float(self.get_parameter("resize_scale").value)
        self.pair_tol_ratio = float(self.get_parameter("pair_tol_ratio").value)
        self.use_dark_map = bool(self.get_parameter("use_dark_map").value)

        # 🔸 ImgNode 인스턴스 (토픽 구독 X)
        self.img_node = ImgNode()

        # 보정행렬
        self.T_g2c = load_T_g2c(self.get_logger())

        # 서비스 (절대 경로로 만들어 로봇 클라이언트와 확실히 일치)
        self.srv = self.create_service(Trigger, "get_base_xyz", self._on_get_base_xyz)

        self.get_logger().info(f"Service ready: get_base_xyz")

    # === [1] 깊이를 항상 '미터'로 정규화 ===
    def _normalize_depth_m(self, depth: np.ndarray) -> np.ndarray:
        """깊이를 m 단위로 통일 (mm로 오면 0.001 곱)."""
        d = depth.astype(np.float32, copy=False)
        # 실내에서 100m를 넘는 값은 비정상 → mm로 판단
        if np.nanmax(d) > 100.0:
            d = d * 0.001
        return d

    # ImgNode에서 유효 데이터 대기
    def _wait_for_valid(self, getter, desc: str, timeout_s=WAIT_TIMEOUT_S):
        t0 = time.time()
        v = getter()
        while (v is None or (isinstance(v, np.ndarray) and v.size == 0)) and (time.time()-t0 < timeout_s) and rclpy.ok():
            rclpy.spin_once(self.img_node, timeout_sec=0.01)
            v = getter()
        return v

    def _get_latest(self):
        color = self._wait_for_valid(self.img_node.get_color_frame, "color")
        depth = self._wait_for_valid(self.img_node.get_depth_frame, "depth")
        intr  = self._wait_for_valid(self.img_node.get_camera_intrinsic, "intrinsic")

        # === [2] 정규화 적용 & 1회 디버그 로그 ===
        if depth is not None:
            depth = self._normalize_depth_m(depth)
        if not hasattr(self, "_dbg_once") and depth is not None:
            self._dbg_once = True
            self.get_logger().info(
                f"depth stats (m): min={float(np.nanmin(depth)):.3f}, max={float(np.nanmax(depth)):.3f}"
            )
            self.get_logger().info(f"intr={intr}")

        return color, depth, intr

    def _process_one_frame(self):
        color, depth_m, intr = self._get_latest()
        if color is None or depth_m is None or intr is None:
            return None, None, "NO_FRAME"

        H, W = color.shape[:2]
        small = cv2.resize(color, (int(W*self.resize_scale), int(H*self.resize_scale)), interpolation=cv2.INTER_AREA)

        gray_like = (cv2.min(cv2.split(small)[0], cv2.min(cv2.split(small)[1], cv2.split(small)[2]))
                     if self.use_dark_map else cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))

        norm = divide_by_blur(gray_like, 30)
        th   = cv2.threshold(norm, 0,255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
        th   = cv2.medianBlur(th, 3)

        pts_small = simpleblob_centers(th)
        if len(pts_small) < 2:
            pts_small = hough_centers(gray_like)
        if len(pts_small) < 2:
            return None, None, "NO_CAND"

        pts_full = np.array([(p[0]/self.resize_scale, p[1]/self.resize_scale) for p in pts_small], dtype=np.float32)

        # 초기 z 추정으로 pair 선택
        z_guess_m = float(np.median(depth_m[depth_m>0])) if np.any(depth_m>0) else 0.4
        exp_px_init = expected_px_distance(intr["fx"], z_guess_m*1000.0)
        best=None; best_err=1e9
        for i in range(len(pts_full)):
            for j in range(i+1, len(pts_full)):
                d = float(np.hypot(*(pts_full[i]-pts_full[j])))
                err = abs(d-exp_px_init)
                if err<best_err:
                    best_err=err; best=(pts_full[i], pts_full[j])
        if best is None:
            return None, None, "NO_PAIR"

        p1, p2 = best
        M = ((p1[0]+p2[0])/2.0, (p1[1]+p2[1])/2.0)

        zc_m = median_depth_m(depth_m, M, patch=2)
        if not (zc_m and zc_m>0):
            return None, None, "NO_DEPTH"

        exp_px = expected_px_distance(intr["fx"], zc_m*1000.0)
        if abs(np.hypot(*(p1-p2)) - exp_px) > exp_px*self.pair_tol_ratio:
            best=None; best_err=1e9
            for i in range(len(pts_full)):
                for j in range(i+1, len(pts_full)):
                    d = float(np.hypot(*(pts_full[i]-pts_full[j])))
                    err = abs(d-exp_px)
                    if err<best_err:
                        best_err=err; best=(pts_full[i], pts_full[j])
            if best is None:
                return None, None, "NO_PAIR"
            p1, p2 = best
            M = ((p1[0]+p2[0])/2.0, (p1[1]+p2[1])/2.0)
            zc_m = median_depth_m(depth_m, M, patch=2)
            if not (zc_m and zc_m>0):
                return None, None, "NO_DEPTH"

        PM = pixel_to_cam3D(M, zc_m, intr["fx"], intr["fy"], intr["ppx"], intr["ppy"])
        cam_xyz_mm = (PM*1000.0).tolist()

        base_xyz_mm = None
        self.get_logger().warn(f"error 2 {self.T_g2c}")
        if self.T_g2c is not None:
            self.get_logger().warn(f"error 3")
            try:
                posx = get_current_posx()[0]  # [x,y,z, rz1, ry, rz2] (mm, deg)
                T_b2g = get_base2gripper_T_from_posx(posx)
                T_b2c = T_b2g @ self.T_g2c
                P_cam_mm = np.array([cam_xyz_mm[0], cam_xyz_mm[1], cam_xyz_mm[2], 1.0], dtype=np.float64)
                P_base_mm = T_b2c @ P_cam_mm
                base_xyz_mm = [float(P_base_mm[0]), float(P_base_mm[1]), float(P_base_mm[2])]
                self.get_logger().warn(f"error 4 {base_xyz_mm} {posx}")
            except Exception as e:
                self.get_logger().warn(f"BASE transform failed: {e}")
                base_xyz_mm = None

        return cam_xyz_mm, base_xyz_mm, "OK" if base_xyz_mm is not None else "NO_BASE"

    def _on_get_base_xyz(self, req, res):
        status = "INIT"; cam_xyz = None; base_xyz = None
        for _ in range(MAX_ATTEMPTS):
            self.get_logger().warn(f"error 1")
            cam_xyz, base_xyz, status = self._process_one_frame()
            if status == "OK": break
            if status in ("NO_BASE","NO_FRAME"): break

        if status == "OK" and base_xyz is not None:
            res.success = True
            res.message = f"{base_xyz[0]:.1f},{base_xyz[1]:.1f},{base_xyz[2]:.1f}"
            self.get_logger().warn(f"result 1: {res.message}")
            return res

        hint = ""
        if cam_xyz is not None:
            hint = f" | cam_xyz(mm)={cam_xyz[0]:.1f},{cam_xyz[1]:.1f},{cam_xyz[2]:.1f}"
        if status == "NO_BASE":
            res.success = False
            res.message = "BASE transform unavailable (need DSR + T_g2c)." + hint
        elif status == "NO_FRAME":
            res.success = False
            res.message = "No frames from ImgNode (check camera running)."
        else:
            res.success = False
            res.message = f"Detection failed: {status}." + hint
        return res

def main():
    node = OutletDetectSrvNode()

    # 🔸 ImgNode와 서비스 노드를 같은 executor에서 돌림
    exec = MultiThreadedExecutor(num_threads=2)
    exec.add_node(node)
    exec.add_node(node.img_node)

    try:
        exec.spin()
    except KeyboardInterrupt:
        pass
    finally:
        exec.shutdown()
        node.destroy_node()
        node.img_node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
