# object_detection/yolo_skeleton_service.py
import os, time, math, collections
import numpy as np
import cv2
from ultralytics import YOLO
from ament_index_python.packages import get_package_share_directory

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from std_srvs.srv import Trigger

# 🔁 RealSense ImgNode 사용
from object_detection.realsense import ImgNode

# -------- Config --------
PACKAGE_NAME = "pick_and_place_voice"
PACKAGE_PATH = get_package_share_directory(PACKAGE_NAME)
MODEL = "yolo11n-pose.pt"
YOLO_MODEL_PATH = os.path.join(PACKAGE_PATH, "resource", MODEL)

IMG_SIZE = 640
DEVICE = os.environ.get("DEVICE", "cpu")  # "cpu" or GPU index like "0"

# === Stretching flow params ===
CALIBRATION_TIME = 5.0        # 초기 포즈 캘리브레이션 시간(초)
POSE_HOLD_TIME   = 3.0        # 각 동작 유지 시간(초)

# 단계 이름
STEPS = [
    "1step: raise arms",
    "2step: open arms",
    "3step: Turn your neck",
]

# COCO keypoint index
NOSE = 0
L_SH, R_SH = 5, 6
L_ELB, R_ELB = 7, 8
L_WRI, R_WRI = 9, 10

# --- Vis ---
TEXT_COLOR = (255, 255, 0)
OK_COLOR   = (0, 200, 0)
ERR_COLOR  = (0, 0, 255)

# ------------------ Pose helpers ------------------
def _get_keypoints_from_result(res):
    """가장 큰 사람 1명 keypoints(xy) numpy 반환. 없으면 None"""
    if (res.keypoints is None) or (len(res.keypoints) == 0):
        return None
    idx = 0
    if (res.boxes is not None) and (len(res.boxes) > 0):
        areas = (res.boxes.xywh[:, 2] * res.boxes.xywh[:, 3]).cpu().numpy()
        idx = int(np.argmax(areas))
    return res.keypoints.xy[idx].cpu().numpy()

def _draw_keypoints(frame, kps):
    if kps is None: return
    for x, y in kps:
        if x > 0 and y > 0:
            cv2.circle(frame, (int(x), int(y)), 4, (0, 255, 0), -1)

def _shoulder_width(kps):
    if kps is None: return None
    lx, ly = kps[L_SH]; rx, ry = kps[R_SH]
    if lx <= 0 or ly <= 0 or rx <= 0 or ry <= 0: return None
    return float(np.linalg.norm(kps[R_SH] - kps[L_SH]))

def _check_step(step_idx, kps, baseline):
    """각 단계 판정 로직"""
    if kps is None or baseline is None:
        return False

    sw = _shoulder_width(kps)
    if sw is None or sw < 1e-6:
        return False

    if step_idx == 0:  # raise arms
        # 손목이 어깨보다 충분히 위에 있는지
        return (kps[L_WRI][1] < kps[L_SH][1] - 40) and \
               (kps[R_WRI][1] < kps[R_SH][1] - 40)

    elif step_idx == 1:  # open arms
        wrist_dist = float(np.linalg.norm(kps[R_WRI] - kps[L_WRI]))
        return (wrist_dist / sw) > 2.0

    elif step_idx == 2:  # Turn your neck
        # 어깨 폭 기준으로 머리의 좌우 이동량 확인
        shoulder_width = abs(kps[R_SH][0] - kps[L_SH][0])
        if shoulder_width < 1e-6:
            return False
        head_offset = abs(kps[NOSE][0] - baseline[NOSE][0]) / shoulder_width
        return head_offset > 0.2

    return False

# ---------------- ROS2 Node ----------------
class SkeletonMonitor(Node):
    def __init__(self):
        super().__init__("skeleton_monitor")
        self.stretching_task = self.create_service(
            Trigger, "stretching_task", self.stretching_flow_callback
        )
        self.model = YOLO(YOLO_MODEL_PATH)
        self.get_logger().info("SkeletonMonitor ready (multi-step stretching).")

        # ✅ RealSense 이미지 노드
        self.img_node = ImgNode()

        # 창 표시 on/off (서버 환경이면 false 권장)
        self.declare_parameter('show_window', True)
        self.show_window = bool(self.get_parameter('show_window').value)

    def _get_latest_frame(self, timeout_sec: float = 1.0):
        """
        ImgNode에서 최신 컬러 프레임을 가져온다.
        필요 시 spin_once로 콜백 처리 기회 제공.
        """
        t0 = time.time()
        frame = self.img_node.get_color_frame()
        while frame is None and (time.time() - t0) < timeout_sec and rclpy.ok():
            rclpy.spin_once(self.img_node, timeout_sec=0.01)
            frame = self.img_node.get_color_frame()
        return frame

    def stretching_flow_callback(self, request, response):
        baseline_pose = None
        calib_start = time.time()
        calibrated = False
        step_idx = 0
        pose_start_t = None

        try:
            while rclpy.ok():
                frame = self._get_latest_frame(timeout_sec=1.0)
                if frame is None:
                    self.get_logger().warn("No frame from RealSense")
                    response.success = False
                    response.message = "frame_timeout"
                    return response

                # Inference
                res = self.model(frame, imgsz=IMG_SIZE, device=DEVICE, verbose=False)[0]
                kps = _get_keypoints_from_result(res)

                # draw
                if self.show_window:
                    _draw_keypoints(frame, kps)

                # 1) Calibration
                if not calibrated:
                    elapsed = time.time() - calib_start
                    left = max(0, int(CALIBRATION_TIME - elapsed))
                    if self.show_window:
                        cv2.putText(frame, f"Initial pose analysis... {left} sec",
                                    (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, TEXT_COLOR, 2)
                        cv2.imshow("Pose Trainer (RealSense)", frame)
                        if cv2.waitKey(1) & 0xFF == ord('q'):
                            response.success = False
                            response.message = "user_quit"
                            return response
                    if elapsed >= CALIBRATION_TIME and kps is not None:
                        baseline_pose = kps.copy()
                        calibrated = True
                        self.get_logger().info("Initial pose calibration complete.")
                    continue

                # 2) Step-by-step stretching
                if step_idx < len(STEPS):
                    if self.show_window:
                        cv2.putText(frame, STEPS[step_idx], (30, 50),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, TEXT_COLOR, 3)

                    ok_step = _check_step(step_idx, kps, baseline_pose) if kps is not None else False
                    if ok_step:
                        if pose_start_t is None:
                            pose_start_t = time.time()
                        hold = time.time() - pose_start_t
                        if self.show_window:
                            cv2.putText(frame, f"HOLD {hold:.1f}/{POSE_HOLD_TIME:.0f}s",
                                        (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 1.0, OK_COLOR, 2)
                        if hold >= POSE_HOLD_TIME:
                            self.get_logger().info(f"Step {step_idx+1} passed: {STEPS[step_idx]}")
                            step_idx += 1
                            pose_start_t = None
                    else:
                        pose_start_t = None
                        if self.show_window:
                            cv2.putText(frame, "HOLD 0.0s", (30, 90),
                                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, ERR_COLOR, 2)
                else:
                    # 모든 단계 완료 → 즉시 성공 반환
                    if self.show_window:
                        cv2.putText(frame, "All poses complete!", (30, 50),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, OK_COLOR, 3)
                        cv2.imshow("Pose Trainer (RealSense)", frame)
                        cv2.waitKey(5)
                    self.get_logger().info("All stretching steps completed. Returning success.")
                    response.success = True
                    response.message = "stretching_ok"
                    return response

                # show
                if self.show_window:
                    cv2.imshow("Pose Trainer (RealSense)", frame)
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        response.success = False
                        response.message = "user_quit"
                        return response

        finally:
            try:
                if self.show_window:
                    cv2.destroyAllWindows()
                    cv2.waitKey(1)
            except Exception:
                pass

        # 정상 루프 종료에 도달하면(실제론 거의 없음) 실패 처리
        response.success = False
        response.message = "no_event"
        return response

# ---------------- Main ----------------
def main(args=None):
    rclpy.init(args=args)
    node = SkeletonMonitor()

    # ✅ ImgNode와 서비스 노드를 함께 돌리기(프레임 콜백 처리)
    exec = MultiThreadedExecutor(num_threads=2)
    exec.add_node(node)          # 서비스/로직
    exec.add_node(node.img_node) # RealSense 프레임 수신

    try:
        exec.spin()
    except KeyboardInterrupt:
        pass
    finally:
        exec.shutdown()
        node.destroy_node()
        node.img_node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == "__main__":
    main()

