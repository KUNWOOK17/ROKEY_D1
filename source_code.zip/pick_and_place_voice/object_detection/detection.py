import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from typing import Any, Callable, Optional, Tuple

from ament_index_python.packages import get_package_share_directory
from od_msg.srv import SrvDepthPosition
from od_msg.srv import SrvInplaneAngle  # 새 srv
from object_detection.realsense import ImgNode
from object_detection.yolo import YoloModel
import threading  
import os
import cv2

PACKAGE_NAME = 'pick_and_place_voice'
PACKAGE_PATH = get_package_share_directory(PACKAGE_NAME)

class ObjectDetectionNode(Node):
    def __init__(self, model_name = 'yolo'):
        super().__init__('object_detection_node')
        self.img_node = ImgNode()
        self.model = self._load_model(model_name)
        self.intrinsics = self._wait_for_valid_data(
            self.img_node.get_camera_intrinsic, "camera intrinsics"
        )
        self.create_service(
            SrvDepthPosition,
            'get_3d_position',
            self.handle_get_depth
        )

        # __init__ 끝부분에 레퍼런스 로드 & 서비스 등록
        self.ref_images = self._load_ref_images()  # 클래스별 정방향 이미지
        self.create_service(SrvInplaneAngle, 'get_inplane_angle', self.handle_get_inplane_angle)
        self.get_logger().info("ObjectDetectionNode initialized.")

        # 🔧 디버그 뷰 파라미터
        self.declare_parameter('debug_view', False)        # True면 뷰어 실행
        self.declare_parameter('view_targets', ['hand'])   # 표시할 클래스들

        if self.get_parameter('debug_view').value:
            self.viewer_thread = threading.Thread(target=self._run_viewer, daemon=True)
            self.viewer_thread.start()
    
    def _load_ref_images(self):
        # resource에 정방향 샘플 배치: ref_phone.png 등
        mp = {
            'phone':  os.path.join(PACKAGE_PATH, 'resource', 'ref_phone.png'),
            'book':   os.path.join(PACKAGE_PATH, 'resource', 'ref_book.png'),
            'wallet': os.path.join(PACKAGE_PATH, 'resource', 'ref_wallet.png'),
            'airpods': os.path.join(PACKAGE_PATH, 'resource', 'ref_airpods.png'),
            'lotion': os.path.join(PACKAGE_PATH, 'resource', 'ref_lotion.png'),
            'pencilcase': os.path.join(PACKAGE_PATH, 'resource', 'ref_pencilcase.png'),
            'vitamin': os.path.join(PACKAGE_PATH, 'resource', 'ref_vitamin.png')
        }
        out = {}
        for k,p in mp.items():
            if os.path.exists(p):
                img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    out[k] = img
        return out
    
    def handle_get_inplane_angle(self, request, response):
        target = request.target
        box, score = self.model.get_best_detection(self.img_node, target)
        if box is None:
            response.angle_deg = 0.0; response.ok = False; response.detail = "no detection"; return response

        frame = self.img_node.get_color_frame()
        if frame is None:
            response.angle_deg = 0.0; response.ok = False; response.detail = "no frame"; return response

        ref = self.ref_images.get(target, None)
        try:
            theta = self._estimate_inplane_angle_from_ref(frame, box, ref)  # 도 단위
            response.angle_deg = float(theta)
            response.ok = True
            response.detail = f"score={score:.2f}"
        except Exception as e:
            response.angle_deg = 0.0; response.ok = False; response.detail = str(e)
        return response
    
    def _estimate_inplane_angle_from_ref(self, frame_bgr, box, ref_gray=None):
        # 1) ROI 추출
        x1,y1,x2,y2 = map(int, box)
        h, w = frame_bgr.shape[:2]
        x1 = max(0, x1); y1 = max(0, y1)
        x2 = min(w-1, x2); y2 = min(h-1, y2)
        roi = frame_bgr[y1:y2, x1:x2]
        if roi.size == 0:
            return 0.0
        roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # 2) 기준 이미지가 있으면 ORB 매칭, 없으면 minAreaRect로 근사
        if ref_gray is None:
            # fallback: 외곽 윤곽 각도
            edges = cv2.Canny(cv2.GaussianBlur(roi_gray,(5,5),0), 50, 150)
            cnts, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if not cnts: return 0.0
            rect = cv2.minAreaRect(max(cnts, key=cv2.contourArea))
            angle = rect[-1]; (w0,h0)=rect[1]
            if w0 < h0: angle += 90.0
            return float(angle)

        # 3) ORB 특징 추출 & 매칭
        orb = cv2.ORB_create(1000)
        k1, d1 = orb.detectAndCompute(ref_gray, None)
        k2, d2 = orb.detectAndCompute(roi_gray, None)
        if d1 is None or d2 is None or len(k1) < 8 or len(k2) < 8:
            return 0.0

        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        matches = bf.knnMatch(d1, d2, k=2)
        good = []
        for m,n in matches:
            if m.distance < 0.75*n.distance:
                good.append(m)
        if len(good) < 8:
            return 0.0

        src = np.float32([k1[m.queryIdx].pt for m in good]).reshape(-1,1,2)
        dst = np.float32([k2[m.trainIdx].pt for m in good]).reshape(-1,1,2)

        H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 3.0)
        if H is None:
            return 0.0

        # 4) 2D 회전각 추정: scale 제거 후 atan2
        # 상단 2x2 부분에서 회전 성분 분리
        a,b,c,d = H[0,0], H[0,1], H[1,0], H[1,1]
        # 등방성 스케일 s = sqrt(a^2 + c^2)
        s = np.sqrt(a*a + c*c) + 1e-9
        r00, r01 = a/s, b/s
        theta = np.degrees(np.arctan2(r01, r00))  # [-180,180]
        # minAreaRect 기준과 유사하게 [-90,90]로 정리
        if theta > 90: theta -= 180
        if theta < -90: theta += 180
        return float(theta)

    def _load_model(self, name):
        """모델 이름에 따라 인스턴스를 반환합니다."""
        if name.lower() == 'yolo':
            return YoloModel()
        raise ValueError(f"Unsupported model: {name}")

    def handle_get_depth(self, request, response):
        """클라이언트 요청을 처리해 3D 좌표를 반환합니다."""
        self.get_logger().info(f"Received request: {request}")
        coords = self._compute_position(request.target)
        response.depth_position = [float(x) for x in coords]
        return response

    def _compute_position(self, target):
        """이미지를 처리해 객체의 카메라 좌표를 계산합니다."""
        rclpy.spin_once(self.img_node)

        box, score = self.model.get_best_detection(self.img_node, target)
        if box is None or score is None:
            self.get_logger().warn("No detection found.")
            return 0.0, 0.0, 0.0
        
        self.get_logger().info(f"Detection: box={box}, score={score}")
        cx, cy = map(int, [(box[0] + box[2]) / 2, (box[1] + box[3]) / 2])
        cz = self._get_depth(cx, cy)
        if cz is None:
            self.get_logger().warn("Depth out of range.")
            return 0.0, 0.0, 0.0

        return self._pixel_to_camera_coords(cx, cy, cz)

    def _get_depth(self, x, y):
        """픽셀 좌표의 depth 값을 안전하게 읽어옵니다."""
        frame = self._wait_for_valid_data(self.img_node.get_depth_frame, "depth frame")
        try:
            return frame[y, x]
        except IndexError:
            self.get_logger().warn(f"Coordinates ({x},{y}) out of range.")
            return None

    def _wait_for_valid_data(self, getter, description):
        """getter 함수가 유효한 데이터를 반환할 때까지 spin 하며 재시도합니다."""
        data = getter()
        while data is None or (isinstance(data, np.ndarray) and not data.any()):
            rclpy.spin_once(self.img_node)
            self.get_logger().info(f"Retry getting {description}.")
            data = getter()
        return data

    def _pixel_to_camera_coords(self, x, y, z):
        """픽셀 좌표와 intrinsics를 이용해 카메라 좌표계로 변환합니다."""
        fx = self.intrinsics['fx']
        fy = self.intrinsics['fy']
        ppx = self.intrinsics['ppx']
        ppy = self.intrinsics['ppy']
        return (
            (x - ppx) * z / fx,
            (y - ppy) * z / fy,
            z
        )
    
    def _run_viewer(self):
        """YOLO 결과를 OpenCV 창으로 보여주는 뷰어(별도 스레드)"""
        try:
            targets = self.get_parameter('view_targets').value
        except Exception:
            targets = ['hand']

        # 문자열로 들어오면 콤마 분리 처리 (예: "hand,phone")
        if isinstance(targets, str):
            targets = [t.strip() for t in targets.split(',') if t.strip()]

        try:
            # YoloModel에 추가한 view_stream() 사용
            self.model.view_stream(self.img_node, targets=targets)
        except Exception as e:
            self.get_logger().error(f"view_stream error: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = ObjectDetectionNode()

    # ✅ 하나의 멀티스레드 executor에 두 노드를 모두 올린다
    exec = MultiThreadedExecutor(num_threads=2)
    exec.add_node(node)          # ObjectDetectionNode
    exec.add_node(node.img_node) # ImgNode (프레임 수신 콜백용)

    try:
        exec.spin()
    finally:
        exec.shutdown()
        node.destroy_node()
        node.img_node.destroy_node()
        rclpy.shutdown()