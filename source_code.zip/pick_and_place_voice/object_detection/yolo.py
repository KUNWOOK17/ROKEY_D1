########## YoloModel ##########
import os
import json
import time
from collections import Counter

import rclpy
from ament_index_python.packages import get_package_share_directory
from ultralytics import YOLO
import numpy as np
import cv2


PACKAGE_NAME = "pick_and_place_voice"
PACKAGE_PATH = get_package_share_directory(PACKAGE_NAME)

YOLO_MODEL_FILENAME = "best.pt"
YOLO_CLASS_NAME_JSON = "class_name_tool.json"

YOLO_MODEL_PATH = os.path.join(PACKAGE_PATH, "resource", YOLO_MODEL_FILENAME)
YOLO_JSON_PATH = os.path.join(PACKAGE_PATH, "resource", YOLO_CLASS_NAME_JSON)


class YoloModel:
    def __init__(self):
        self.model = YOLO(YOLO_MODEL_PATH)
        with open(YOLO_JSON_PATH, "r", encoding="utf-8") as file:
            class_dict = json.load(file)
            self.reversed_class_dict = {v: int(k) for k, v in class_dict.items()}

    def get_frames(self, img_node, duration=1.0):
        """get frames while target_time"""
        end_time = time.time() + duration
        frames = {}

        while time.time() < end_time:
            rclpy.spin_once(img_node)
            frame = img_node.get_color_frame()
            stamp = img_node.get_color_frame_stamp()
            if frame is not None:
                frames[stamp] = frame
            time.sleep(0.01)

        if not frames:
            print("No frames captured in %.2f seconds", duration)

        print("%d frames captured", len(frames))
        return list(frames.values())

    def get_best_detection(self, img_node, target):
        rclpy.spin_once(img_node)
        frames = self.get_frames(img_node)
        if not frames:  # Check if frames are empty
            return None

        results = self.model(frames, verbose=False)
        print("classes: ")
        print(results[0].names)
        detections = self._aggregate_detections(results)
        label_id = self.reversed_class_dict[target]
        print("label_id: ", label_id)
        print("detections: ", detections)

        matches = [d for d in detections if d["label"] == label_id]
        if not matches:
            print("No matches found for the target label.")
            return None, None
        best_det = max(matches, key=lambda x: x["score"])
        return best_det["box"], best_det["score"]

    def _aggregate_detections(self, results, confidence_threshold=0.5, iou_threshold=0.5):
        """
        Fuse raw detection boxes across frames using IoU-based grouping
        and majority voting for robust final detections.
        """
        raw = []
        for res in results:
            for box, score, label in zip(
                res.boxes.xyxy.tolist(),
                res.boxes.conf.tolist(),
                res.boxes.cls.tolist(),
            ):
                if score >= confidence_threshold:
                    raw.append({"box": box, "score": score, "label": int(label)})

        final = []
        used = [False] * len(raw)

        for i, det in enumerate(raw):
            if used[i]:
                continue
            group = [det]
            used[i] = True
            for j, other in enumerate(raw):
                if not used[j] and other["label"] == det["label"]:
                    if self._iou(det["box"], other["box"]) >= iou_threshold:
                        group.append(other)
                        used[j] = True

            boxes = np.array([g["box"] for g in group])
            scores = np.array([g["score"] for g in group])
            labels = [g["label"] for g in group]

            final.append(
                {
                    "box": boxes.mean(axis=0).tolist(),
                    "score": float(scores.mean()),
                    "label": Counter(labels).most_common(1)[0][0],
                }
            )

        return final

    def _iou(self, box1, box2):
        """
        Compute Intersection over Union (IoU) between two boxes [x1, y1, x2, y2].
        """
        x1, y1 = max(box1[0], box2[0]), max(box1[1], box2[1])
        x2, y2 = min(box1[2], box2[2]), min(box1[3], box2[3])
        inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0.0
    
    def view_stream(self, img_node, targets=None, conf_thres=0.35, iou_thres=0.5, window_name="YOLO Viewer"):
        """
        OpenCV 창으로 YOLO 결과를 실시간 확인.
        - targets: ['hand', 'phone']처럼 보고 싶은 클래스명 리스트 (None이면 전부 표시)
        - q: 종료, p: 일시정지/재개, s: 스크린샷 저장
        """
        # 클래스명 ↔ id 매핑
        try:
            names = self.model.model.names  # ultralytics 내부 names
        except Exception:
            names = getattr(self.model, 'names', None) or {}
        name2id = {n: i for i, n in names.items()} if isinstance(names, dict) else {}
        want_ids = None
        if targets:
            want_ids = set()
            for t in targets:
                # 우선 사용자가 준 class_name_tool.json 기반(한글→id 역매핑) 시도
                if t in self.reversed_class_dict:
                    want_ids.add(self.reversed_class_dict[t])
                # 모델 내부 names에도 있으면 허용
                if t in name2id:
                    want_ids.add(name2id[t])
            if not want_ids and targets:
                print(f"[WARN] targets={targets} 가 클래스에 없습니다. 전체 표시로 전환.")
                want_ids = None

        # 윈도우 생성 (일부 환경에서 실패할 수 있어 try)
        try:
            cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        except cv2.error as e:
            print("[ERR] GUI 윈도우 생성 실패:", e)
            print(" - Ubuntu라면: sudo apt-get install -y libgtk-3-dev && 재설치 필요할 수 있음")
            print(" - Wayland 사용 시: export QT_QPA_PLATFORM=xcb 후 재실행 권장")
            return

        paused = False
        last_t = time.time()
        fps = 0.0
        shot_idx = 0

        print("[INFO] Press 'q' to quit, 'p' to pause/resume, 's' to save frame")

        while rclpy.ok():
            if not paused:
                rclpy.spin_once(img_node, timeout_sec=0.01)
                frame = img_node.get_color_frame()
                if frame is None:
                    # 프레임 없으면 잠깐 쉼
                    time.sleep(0.01)
                    continue

                # YOLO 추론 (단일 프레임)
                results = self.model.predict(
                    source=frame,
                    verbose=False,
                    conf=conf_thres,
                    iou=iou_thres
                )

                vis = frame.copy()
                # FPS 계산
                now = time.time()
                dt = now - last_t
                last_t = now
                if dt > 0:
                    fps = 1.0 / dt

                # 결과 그리기
                res = results[0]
                if res.boxes is not None and len(res.boxes) > 0:
                    boxes = res.boxes.xyxy.cpu().numpy()
                    scores = res.boxes.conf.cpu().numpy()
                    clses  = res.boxes.cls.cpu().numpy().astype(int)

                    for (xyxy, sc, cid) in zip(boxes, scores, clses):
                        if want_ids is not None and cid not in want_ids:
                            continue
                        x1, y1, x2, y2 = map(int, xyxy)
                        label = names.get(cid, str(cid)) if isinstance(names, dict) else str(cid)
                        txt = f"{label} {sc:.2f}"
                        # 박스 & 라벨
                        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 255), 2)
                        (tw, th), bl = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                        cv2.rectangle(vis, (x1, y1 - th - 6), (x1 + tw + 4, y1), (0, 255, 255), -1)
                        cv2.putText(vis, txt, (x1 + 2, y1 - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,0), 2, cv2.LINE_AA)

                # 상단에 FPS, 필터 정보
                header = f"FPS: {fps:.1f}"
                if want_ids is not None:
                    sel_names = [names[i] if isinstance(names, dict) and i in names else str(i) for i in sorted(want_ids)]
                    header += f" | targets: {', '.join(sel_names)}"
                cv2.putText(vis, header, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2, cv2.LINE_AA)

                cv2.imshow(window_name, vis)

            # 키 입력
            k = cv2.waitKey(1) & 0xFF
            if k == ord('q'):
                break
            elif k == ord('p'):
                paused = not paused
            elif k == ord('s') and not paused:
                save_path = os.path.join(PACKAGE_PATH, f"yolo_view_{shot_idx:03d}.png")
                cv2.imwrite(save_path, vis)
                print(f"[INFO] saved: {save_path}")
                shot_idx += 1

        cv2.destroyWindow(window_name)
