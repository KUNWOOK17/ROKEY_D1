import numpy as np
import tflite_runtime.interpreter as tflite
import librosa
import os

# TFLite 모델 파일 경로
MODEL_PATH = "military_song_model.tflite"

def run_inference(audio_file_path):
    """
    TFLite 모델을 로드하고 오디오 파일에 대한 추론을 실행합니다.
    """
    try:
        # Flex Delegate 로드 (오류 해결을 위해 필요)
        from tflite_runtime.interpreter import load_delegate
        delegates = [load_delegate('libtensorflowlite_flex.so')]
    except ImportError:
        # Flex delegate를 찾을 수 없는 경우 경고 메시지 출력
        print("Warning: Flex delegate not found. The model might not run correctly.")
        delegates = None

    # TFLite 인터프리터 로드
    interpreter = tflite.Interpreter(model_path=MODEL_PATH, experimental_delegates=delegates)
    interpreter.allocate_tensors()

    # 모델의 입출력 텐서 정보 가져오기
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # 오디오 파일 전처리
    audio, sr = librosa.load(audio_file_path, sr=16000)
    
    # 모델 입력 크기에 맞게 오디오 데이터 패딩 또는 자르기
    input_shape = input_details[0]['shape']
    target_length = input_shape[1]
    
    if len(audio) < target_length:
        audio = np.pad(audio, (0, target_length - len(audio)))
    else:
        audio = audio[:target_length]
        
    mel_spectrogram = librosa.feature.melspectrogram(y=audio, sr=sr)
    mel_spectrogram = mel_spectrogram.astype(np.float32)

    # 모델에 입력 데이터 설정
    interpreter.set_tensor(input_details[0]['index'], np.expand_dims(mel_spectrogram, axis=0))

    # 추론 실행
    interpreter.invoke()

    # 예측 결과 가져오기
    output_data = interpreter.get_tensor(output_details[0]['index'])
    confidence = output_data[0][0]

    return confidence

if __name__ == "__main__":
    # 테스트할 오디오 파일 경로 (예시)
    test_audio_path = "audio_data/army/torch_1.wav"

    if os.path.exists(test_audio_path):
        confidence_score = run_inference(test_audio_path)
        print(f"'{test_audio_path}'에 대한 예측 점수: {confidence_score:.4f}")
        if confidence_score > 0.5:
            print("▶ 이 파일은 군가일 가능성이 높습니다.")
        else:
            print("▶ 이 파일은 군가일 가능성이 낮습니다.")
    else:
        print(f"Error: {test_audio_path} 파일을 찾을 수 없습니다.")