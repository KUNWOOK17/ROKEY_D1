#!/usr/bin/env python3
import os, subprocess
from openai import OpenAI
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from ament_index_python.packages import get_package_share_directory
from od_msg.srv import TTS
from dotenv import load_dotenv

############ Package Path & Environment Setting ############
current_dir = os.getcwd()
package_path = get_package_share_directory("pick_and_place_voice")

is_laod = load_dotenv(dotenv_path=os.path.join(f"{package_path}/resource/.env"))
openai_api_key = os.getenv("OPENAI_API_KEY")

class TTSNode(Node):
    def __init__(self):
        super().__init__("tts_node")
        self.srv = self.create_service(TTS, 'tts/speak', self.on_text)
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY가 비어 있습니다.")
        self.client = OpenAI(api_key=api_key)
        self.get_logger().info("TTS node ready (streaming).")

    def on_text(self, req, res):
        self.get_logger().info(f"REQ text='{req.text}', stream={req.stream}")
        if not req.text: return
        self.get_logger().info(f"TTS: {req.text}")

        # 재생 함수들
        def play_mp3(iter_bytes):
            p = subprocess.Popen(["mpg123", "-q", "-"], stdin=subprocess.PIPE)
            for chunk in iter_bytes:
                if p.stdin: p.stdin.write(chunk)
            if p.stdin: p.stdin.close()
            p.wait()

        def play_wav(iter_bytes):
            p = subprocess.Popen(["aplay", "-q", "-t", "wav"], stdin=subprocess.PIPE)
            for chunk in iter_bytes:
                if p.stdin: p.stdin.write(chunk)
            if p.stdin: p.stdin.close()
            p.wait()

        # WAV 우선, 실패 시 MP3 폴백
        try:
            with self.client.audio.speech.with_streaming_response.create(
                model="gpt-4o-mini-tts", voice="nova", input=req.text, format="wav"
            ) as resp:
                play_wav(resp.iter_bytes(8192))
                return
        except TypeError:
            pass
        with self.client.audio.speech.with_streaming_response.create(
            model="gpt-4o-mini-tts", voice="nova", input=req.text
        ) as resp:
            play_mp3(resp.iter_bytes(8192))
        
        res.ok = True
        res.detail = "done"
        return res

def main():
    rclpy.init()
    node = TTSNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
