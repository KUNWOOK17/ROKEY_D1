import os
import rclpy
import pyaudio
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from std_srvs.srv import Trigger

from voice_processing.MicController import MicController, MicConfig
# from voice_processing.wakeup_word import WakeupWord
from voice_processing.stt import STT

############ Package Path & Environment Setting ############
current_dir = os.getcwd()
package_path = get_package_share_directory("pick_and_place_voice")

is_laod = load_dotenv(dotenv_path=os.path.join(f"{package_path}/resource/.env"))
openai_api_key = os.getenv("OPENAI_API_KEY")

############ GetKeyword Node ############
class GetKeyword(Node):
    def __init__(self):
        super().__init__("get_keyword_node")

        self.llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0.5,
            openai_api_key=openai_api_key
        )

        prompt_content = """
            당신은 사용자의 문장에서 특정 명령어들을 추출해야 합니다.
            <목표>
                - 문장에서 다음 리스트에 포함된 명령어를 최대한 정확히 추출하세요.
                - 문장에 등장하는 명령어에 대응하는 물품 리스트와 함께 결과를 반환하세요.
            <명령어 리스트>
                - [학교, 데이트, 핸드폰충전, 핸드폰가져와, 공부, 씻고왔어, 쟈비스, 일어나세요]
            <전체 물품 리스트>
                - [phone, book, wallet, lotion, vitamin, airpods, pencilcase]
            <명령어 대응 물품 리스트>
                학교 => [pencilcase, phone, airpods]
                데이트 => [wallet, phone, airpods]
                핸드폰충전 => [phone]
                핸드폰가져와 => [phone]
                공부 => [book, pencilcase]
                씻고왔어 => [lotion, vitamin]
            <출력 형식>
                - 다음 형식을 반드시 따르세요: [명령어1, 명령어2...]
                - 명령어와 물품은 각각 공백으로 구분
                - 명령어가 없으면 앞쪽은 공백 없이 비우고, 물품이 없으면 '/' 뒤는 공백 없이 비웁니다.
                - 명령어와 물품의 순서는 등장 순서를 따릅니다.
                - 일어나세요가 들린다면 "alarm"이라는 키워드를 반환합니다.
            <특수 규칙>
                - 리스트에 없는 물품이지만 사용자가 특별히 언급한 경우(예: "학교 가는데 필통도 챙겨줘" → pencilcase)는 전체 물품 리스트에 있다면 출력에 포함해서 반환하세요.
                - 다수의 명령어가 동시에 등장할 경우 처음에 입력된 명령어에 해당하는 것들을 출력하세요.
                - 자비스, 쟈비쓰 이런 변형은 "쟈비스"로 통일해서 인식합니다.
            <출력 규칙(매우 중요)>
                - 항상 슬래시(`/`)를 포함해 한 줄로 출력합니다.
                - 왼쪽=명령어(또는 키워드), 오른쪽=물품들
                - 왼쪽이 없으면 비워두되 `/`는 반드시 포함: " / 물품들"
                - 오른쪽이 없으면 "명령어들 / "
                - 일어나세요가 들리면 "alarm / " (물품 없음)

            <올바른 예>
                학교 / wallet phone
                데이트 / wallet phone
                핸드폰충전 / phone
                핸드폰가져다줘 / phone
                alarm / 
                쟈비스 /

            <잘못된 예(금지)>
                학교, 데이트     (슬래시 없음 ❌)
                alarm            (슬래시 없음 ❌)
            <사용자 입력>
            "{user_input}"
        """

        self.prompt_template = PromptTemplate(
            input_variables=["user_input"], template=prompt_content
        )
        self.lang_chain = self.prompt_template | self.llm
        self.stt = STT(openai_api_key=openai_api_key)

        mic_config = MicConfig(
            chunk=12000,
            rate=48000,
            channels=1,
            record_seconds=5,
            fmt=pyaudio.paInt16,
            device_index=10,
            buffer_size=24000,
        )
        self.mic_controller = MicController(config=mic_config)
        # self.wakeup_word = WakeupWord(mic_config.buffer_size)

        self.get_logger().info("MicRecorderNode initialized.")
        self.get_logger().info("wait for client's request...")

        self.get_keyword_srv = self.create_service(
            Trigger, "get_keyword", self.get_keyword
        )

    def extract_keyword(self, output_message):
        response = self.lang_chain.invoke({"user_input": output_message})
        result = response.content.strip()
        object_str, target_str = result.split("/")
        object_list = object_str.split() if object_str else []
        target_list = target_str.split() if target_str else []

        print(f"llm's response: {result}")
        return object_list, target_list

    def get_keyword(self, request, response):
        try:
            self.mic_controller.open_stream()
            # self.wakeup_word.set_stream(self.mic_controller.stream)
        except OSError:
            self.get_logger().error("Error: Failed to open audio stream")
            return None

        # while not self.wakeup_word.is_wakeup():
        #     pass

        output_message = self.stt.speech2text()
        object_list, target_list = self.extract_keyword(output_message)

        self.get_logger().warn(f"Detected tools: {object_list}")
        self.get_logger().warn(f"Detected targets: {target_list}")

        response.success = True
        response.message = " ".join(object_list + target_list)
        return response


def main():
    rclpy.init()
    node = GetKeyword()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
