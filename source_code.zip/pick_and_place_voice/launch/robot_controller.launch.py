# pick_and_place_voice/launch/bringup_all.launch.py
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, GroupAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Launch arguments (필요시 바꿔 쓰기)

    node_object_detection = Node(
        package="pick_and_place_voice",
        executable="object_detection",
        name="object_detection_node",
        output="screen",
    )

    node_skeleton = Node(
        package="pick_and_place_voice",
        executable="skeleton_node",
        name="skeleton_monitor",
        output="screen",
    )

    node_stretching = Node(
        package="pick_and_place_voice",
        executable="stretching",
        name="stretching_task",
        output="screen",
    )

    node_robot_control = Node(
        package="pick_and_place_voice",
        executable="robot_control_main",
        name="robot_control",
        output="screen",
    )

    node_tts_node_control = Node(
        package="pick_and_place_voice",
        executable="tts_node",
        name="tts_node",
        output="screen",
    )

    node_charging_node_control = Node(
        package="pick_and_place_voice",
        executable="get_charger",
        name="charging_node",
        output="screen",
    )

    return LaunchDescription([
        node_object_detection,
        node_skeleton,
        node_stretching,
        node_robot_control,
        node_tts_node_control,
        node_charging_node_control
    ])
